# itcs333-projectgroup6

Sameera Abdul Bari   202200208   Club Activities
Zain Abdulnoor       202200129   Campus News 
Bayan Isa Yusuf      202202026   Student Marketplace
Dana Hameed          202202881   Events Calender
Reem Khaled          202200388   Course Reviews
Marwa aljar          202203007   Course Notes
